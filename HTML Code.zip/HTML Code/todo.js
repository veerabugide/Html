function c(val){
    document.getElementById("d").value=val;
}
function e(){
    try{
        c(document.getElementById("d").value);
    }
    catch(error){
        c("error");
    }
}