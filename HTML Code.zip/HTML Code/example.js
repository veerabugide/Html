//If else conditions
// let hour = 9;

// if(hour >=6 && hour <12){
//     console.log("Good Morning");
// }

// else if(hour >=12 && hour <18){
//     console.log("Good Afternoon");
// }
// else{
//     console.log("Good Evening");
// }

//Switch statement
// let role="superadmin";

// switch(role){
//     case 'superadmin':
//         console.log("Super Admin");
//         break;

//         case 'guest':
//         console.log("Guest");
//         break;

//         case 'peovider':
//         console.log("Provider");
//         break;

//         default:
//             console.log("Default");
//             break;
// }

//loop - for,while,do..while, for..in,for of

//for loop
// for(let i=0;i<10;i++){
//     if(i%2===0)
//     {
//     console.log("Even number",i);
//     }
//     else console.log("Odd No",i)
// }

//while Loop
// let i=0
// while(i<10){
//     if(i%2 === 0)
//     console.log("Even",i);
//     i++;
// }

//Do while Loop
// let i=0;
// do{
//     if(i%2 === 0)
//     console.log("Even;",i);
//     i++;
// }while(i<0);


//for-in
// const person={
//     name:"hemanth",
//     age:30,
// };
// for(let key in person){
//     console.log(key,person[key]);
// }

//const productList =["bread","Jam","Chocloate"];
// for(let i in productList){
//     console.log(i,productList[i]);
// }


//For Off
//const productList =["bread","Jam","Chocloate"];
// for(let product of productList){
//     console.log(product);
// }

// let i=0;
// while(i<=10){
//    // console.log(i);
//     // if(i==3)break;
//     if(i%2!==0){
//         i++;
//         continue;
//     }
//     console.log(i);
//     i++;
// }

// function prime(number){
//     for(let num=2;num<=number;num++){
//          let count=0;
//         for(let i=2;i<=num/2;i++)
//         {
//             if(num%i==0)
//             {
//                 count++;
//             }
//         }
//         if(num ===2 || num === 1)
//         {
//             console.log(num+" is number is co prime ");
//         }
//         else if(count ===0){
//             console.log(num+" Its a prime number");
//         }
//     }
// }
// prime(20);


//14-10-2021

// const numbers=[2,3];

// //Adding ELements at end
// numbers.push(4,5);

// // console.log(numbers);

// //Adding at start
// numbers.unshift(0,1);
// console.log(numbers);

// //Adding at middle
// numbers.splice(2,1,'x','y');
// console.log(numbers);


//Finding Elements(Primitive values)
//Index of Array 
// const numbers=[1,2,3,4,1,2];
// console.log(numbers.indexOf(2));
// console.log(numbers.indexOf(2,2));
// console.log(numbers.lastIndexOf(2));
// console.log(numbers.indexOf(2)!==-1);
// console.log(numbers.includes(3,2));//second parameter tells that searching start from given index
// console.log(numbers.length);


//Finding elements of objects
// const students=[
//     {id: 1,name:'vasanth'},
//     {id: 2,name:'veera'}
// ];

// const student=students.find(function(student){
//     return student.id ==="abc";
// });
// console.log(student);

//FInding the index of elements 
// const students=[
//     {id: 1,name:'vasanth'},
//     {id: 2,name:'veera'}
// ];

// const student=students.findIndex(function(student){
//     return student.id ==="abc";
// });
// console.log(student);



//Using Arrow functions
// const students=[
//         {id: 1,name:'vasanth'},
//         {id: 2,name:'veera'}
//     ];
    
//     const student=students.find(student=>student.name ==="vasanth");
//     console.log(student);



//Removing elemts from an array

// const numbers=[1,2,3,4,5];
// const a=numbers.pop();//Removing ELements at end
// console.log(numbers);
// console.log(a);

// // //Removing at start
// const first=numbers.shift();
// console.log(first);
// console.log(numbers);
 
// //removing at middle or desired location
// numbers.splice(2,1);
// console.log(numbers);


//Deleteing all numbers from array
//let numbers=[1,2,3,4,5];
//solution 1 to delete all elements in an array
// numbers=[];
// console.log(numbers);

//solution 2 (Better Solution) Best
// numbers.length=0;
// console.log(numbers);

//solution 3 (Better solution) //ok
// numbers.splice(0,numbers.length);
// console.log(numbers);

//solution 4 (Bad solution)
// while(numbers.length > 0){
//     numbers.pop();
// }
// console.log(numbers);


// Combining two arrays

// const first=[1,2,3];
// const second=[4,5,6];

// // const combine=first.concat(second);
// const combine=[...first,...second];//Combines two array
// console.log(combine);
// console.log(combine.slice(1,4)); //Displays from 1 to 4 index data //Its a copy of original array

// concatinatig reference and array 
// const first=[{id:1}];
// const second=[4,5,6];

// const combine=first.concat(second);
// console.log(combine);


// Sorting 
// const numbers=[3,2,4,1];
// numbers.sort();
// console.log(numbers);
// numbers.reverse();
// console.log(numbers);


// const students=[
//     {id:1,name:'vasanth'},
//     {id:2,name:'veera'},
//     {id:3,name:'santosh'},
//     ];

//     students.sort(function(a,b){
//         const nameA=a.name.toUpperCase();
//         const nameB=b.name.toUpperCase();
// if(a.name<b.name)return -1;
// else if(a.name>b.name) return 1;
// return 0;
//     });

//    console.log(students);



// Task sum of pair

function getpair(array,targetsum){
     for(let i=0;i<array.length-1;i++){   0,1,2,3,4
   
        for(let j=i;j<array.length;j++){

            let sum=array[i]+array[j+1];

             if(targetsum===sum){

                console.log('(',array[i],',',array[j+1],')');

            }
        }
    }
}
getpair([0,1,2,3,4,5,6,7,8],8);